#ifndef LISTADOBLE_H_INCLUDED
#define LISTADOBLE_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MIN(a,b)((a) < (b) ? (a) : (b))

typedef struct sNodoD{
    void* informacion;
    size_t tam_informacion;
    struct sNodoD* siguiente;
    struct sNodoD* anterior;
}tNodoD;

typedef tNodoD* tListaDoble;

typedef void (*tAccionD)(void *elem, void *extra);
typedef int (*tCmpD)(const void *a, const void *b);

void crearListaD(tListaDoble* p);
int agregarAlFinal(tListaDoble* p, void* informacion, size_t tam_informacion);
int quitarDelFinal(tListaDoble* p, void* informacion, size_t tam_informacion);
int agregarAlComienzo(tListaDoble* p, void* informacion, size_t tam_informacion);
int quitarDelComienzo(tListaDoble* p, void* informacion, size_t tam_informacion);
int obtenerPosicionN(tListaDoble* p, void* informacion, size_t tam_informacion, int N);
void vaciarLista(tListaDoble *p);
int eliminarDeListaDoble(tListaDoble *p, const void *clave, void *dest, size_t tamDest, tCmpD cmp);
void recorrerListaDoble(const tListaDoble *p, tAccionD accion, void *extra);
#endif // LISTADOBLE_H_INCLUDED
